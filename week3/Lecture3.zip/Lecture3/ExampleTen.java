package Lecture3;

public class ExampleTen {

	public static void main(String[] args) {
		
		int counter;
		for (counter = 1; counter <= 10; counter ++);
			System.out.println("*");

	}

}

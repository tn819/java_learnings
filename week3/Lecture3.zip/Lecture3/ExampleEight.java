package Lecture3;

public class ExampleEight {

	public static void main(String[] args) {
		
		int sum = 0;
		int counter = 0;
		do {
			sum+=counter;
			counter++;
		} while (counter<=10);
		
		System.out.println(sum);

	}

}

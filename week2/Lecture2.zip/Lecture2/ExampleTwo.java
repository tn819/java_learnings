package Lecture2;

public class ExampleTwo {

	public static void main(String[] args) {
		
		boolean bool = false;
		
		if (bool) {
			System.out.println("bool evaluates to true");
		} else {
			System.out.println("bool evaluates to false");
		}

	}

}

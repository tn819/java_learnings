package Lecture2;

public class ExampleSix {

	public static void main(String[] args) {
		
		String yesno = "Y";
		
		switch (yesno) {
			case "yes":
			case "Yes":
			case "y":
			case "Y":
				System.out.println("Yes!!!");
				break;
			case "no":
			case "No":
			case "n":
			case "N":
				System.out.println("No!!!");
				break;
			default:
				System.out.println("Maybe???");
		}

	}

}

package Lecture2;

public class ExampleFive {

	public static void main(String[] args) {
		
		int x = 5;
		int y = 6;
		int z = 7;
		
		int min;
		
//		if (x<y) {
//			min = x;
//		} else {
//			min = y;
//		}
		
		min = x<y ? (x<z ? x : z) : (y<z ? y : z);

		System.out.println(min);
		
	}

}

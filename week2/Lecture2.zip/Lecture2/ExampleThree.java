package Lecture2;

public class ExampleThree {

	public static void main(String[] args) {
		
		int number = 2;
		
		if (number == 0) {
			System.out.println("number is equal to zero");
		} else if (number == 1) {
			System.out.println("number is equal to one");
		} else {
			System.out.println("number is not zero or one");
		}

	}

}

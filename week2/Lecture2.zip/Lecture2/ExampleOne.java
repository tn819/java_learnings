package Lecture2;

public class ExampleOne {

	public static void main(String[] args) {
		
		double taxRate;
		taxRate = 0.1;
		int income = 23000;
		
		boolean answer = taxRate>.25 && income<20000;
		System.out.println(answer);
		
		int temperature = 52;
		double humidity = .34;
		
		answer = temperature<=75 || humidity<.7;
		System.out.println(answer);

		int age = 25;
		answer = age>21 && age<60;
		System.out.println(answer);
		
		age = 21;
		answer = age==21 || age==22;
		System.out.println(answer);
	}

}

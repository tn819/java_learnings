package Lecture2;

public class ExampleFour {

	public static void main(String[] args) {
		
		String x = "hello";
		String y = "hello";
		String z = "hi";
		
		String a = "Hello";
		
		System.out.println(x.equals(y));
		System.out.println(x.equals(z));
		System.out.println(x.equals(a));
		System.out.println(x.equalsIgnoreCase(a));

		
		System.out.println("a".compareTo("c"));
		System.out.println("c".compareTo("C"));
		System.out.println("a".compareTo("a"));
		
		System.out.println("hi".compareTo("hello"));
		System.out.println("a".compareTo("C"));
		
	}

}
